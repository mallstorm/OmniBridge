@echo off
setlocal
set ROOT=%~dp0
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%ROOT%scripts\account-doctor.ps1" -Root "%ROOT%" %*
endlocal

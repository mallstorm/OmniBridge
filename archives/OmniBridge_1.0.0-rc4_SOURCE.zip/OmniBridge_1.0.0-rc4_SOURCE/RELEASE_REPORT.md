# OmniBridge 1.0.0-rc4 — Release Report

## Назначение

RC4 — точечный VS Code authentication hotfix после повторного `invalid local bridge key` на реальной установке RC3. Все исправления RC3 (GigaChat embedded CA, model/provider icons, Doctor scores, +1 font/readability) сохранены.

## Причина

`chatLanguageModels.json` и BYOK SecretStorage VS Code — разные состояния. RC3 использовал `requestHeaders.x-bridge-key = ${apiKey}`; если VS Code продолжал подставлять stale BYOK secret, Core закономерно отвечал 401.

## Исправление

- sync preflight всё так же проверяет текущий Data API Key против запущенного Core;
- `/bridge/vscode/export` повышен до contract 2.2;
- каждая модель получает literal `Authorization: Bearer <current-key>` и `x-bridge-key: <current-key>`;
- documented well-known `Authorization` override подавляет inferred/default VS Code auth header;
- фактический запрос не зависит от `${apiKey}` substitution;
- Core по-прежнему принимает Bearer/x-api-key/api-key/x-bridge-key и проверяет все кандидаты, поэтому stale Bearer не мешает правильному x-bridge-key;
- HTTP 401 получает safe diagnostic headers с fingerprint и names-only перечнем auth headers; raw key не логируется.

## GigaChat/UI

Встроенный Russian Trusted Root CA и TLS verification RC3 сохранены. 91 provider icon, 20 family icons, Doctor/Agent/Coding/Reliability UI и увеличенный на +1 шрифт также сохранены. UI остаётся 1260×740, Tray 1000×672.

## Windows acceptance

После установки RC4 обязательно снова выполнить `Интеграция -> Синхронизировать модели`, полностью закрыть VS Code и открыть заново. Старый `chatLanguageModels.json` provider будет заменён актуальным OmniBridge provider.

## Validation

- `go test ./...`: PASS;
- `go vet ./...`: PASS;
- targeted race suites: PASS;
- Windows x64 `CGO_ENABLED=0` cross-vet/build: PASS;
- 145 Go tests;
- PowerShell UTF-8 BOM: 12/12;
- XAML parse: 14/14;
- embedded PE manifest: 1.0.0.04.
